/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao2;
import java.util.Scanner;
/**
 *
 * @author Hyakume
 */
public class App {

    public static void main(String[] args) {
       
        Scanner teclado = new Scanner(System.in);
        Pessoa pessoa = new Pessoa();
        
        System.out.println("Qual o seu peso? ");
        pessoa.peso = teclado.nextDouble();
        
        System.out.println("Qual a sua altura? ");
        pessoa.altura = teclado.nextDouble();
        
        double imc = pessoa.calcularImc();
        
        System.out.println("O seu IMC é: " + imc);
    }
    
}
