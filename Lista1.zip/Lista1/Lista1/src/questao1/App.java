/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao1;
/**
 *
 * @author Hyakume
 */
public class App {

    public static void main(String[] args) {
       
        Pessoa pessoa = new Pessoa();
               
        pessoa.peso = 78;
        pessoa.altura = 1.75;
        
        double imc = pessoa.calcularImc();
        
        System.out.println("O IMC é: " + imc);
    }
    
}
