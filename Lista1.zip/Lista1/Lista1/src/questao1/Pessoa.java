/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package questao1;
/**
 *
 * @author Hyakume
 */
public class Pessoa {
    
    double altura;
    double peso;      
    
    public double calcularImc(){
        
        double imc = peso / (altura * altura);
        
        return imc;
    }  
}
