package com.mycompany.lista4;

public class Lista4 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
