package questao3;

import javax.swing.JOptionPane;

public class AppQuestao3Ui {

    public static void main(String[] args) {
        
        Retangulo retangulo = new Retangulo();
        
        String comprimentoStr = JOptionPane.showInputDialog("Qual o comprimento do retângulo:");
        double comprimento = Double.parseDouble(comprimentoStr);
        retangulo.setComprimento((int) comprimento);
        
        String alturaStr = JOptionPane.showInputDialog("Digite a altura do retângulo:");
        double altura = Double.parseDouble(alturaStr);
        retangulo.setAltura((int) altura);
        
        double area = (int) retangulo.calularArea();
        double perimetro = (int) retangulo.calcularPerimetro();

        String mensagem = String.format("Área: %.2f\nPerímetro: %.2f", area, perimetro);
        JOptionPane.showMessageDialog(null, mensagem, "Resultado", JOptionPane.INFORMATION_MESSAGE);
    }   
}
