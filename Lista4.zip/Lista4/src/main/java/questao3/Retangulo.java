package questao3;

public class Retangulo {
    
    private int altura;
    private int comprimento;
    
     public Retangulo(){
        this.altura = 0;
        this.comprimento = 0;   
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getComprimento() {
        return comprimento;
    }

    public void setComprimento(int comprimento) {
        this.comprimento = comprimento;
    }
    
    public Retangulo(int comprimento, int altura){
        this.altura = altura;
        this.comprimento = comprimento;
    }
    
    public int calcularPerimetro(){
        return (this.altura * 2) + (this.comprimento * 2);
    }
    
    public int calularArea(){
        return this.comprimento * this.altura;
    }
    
}
