package questao4;

public class Retangulo {
    
    public Retangulo(){
        this.altura = 0;
        this.comprimento = 0;   
    }
    
    private int altura;
    private int comprimento;

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura){
        if (altura <= 0){
            throw new IllegalArgumentException("Valor incorreto para altura: ");
        }
        this.altura = altura;
    }

    public int getComprimento() {
        return comprimento;
    }

    public void setComprimento(int comprimento){
        if (comprimento <= 0){
            throw new IllegalArgumentException("Valor incorreto para altura: ");
        }
        this.comprimento = comprimento;
    }
    
    //retangulo é 
    public Retangulo(int comprimento, int altura){
        this.altura = altura;
        this.comprimento = comprimento;
    }
    
    //cacular o perimetro = a soma de todos os lados
    public int calcularPerimetro(){
        return (altura * 2) + (comprimento * 2);
    }
    
    //calcular area = A=b.h = area=comprimento.altura
    public int calularArea(){
        return comprimento * altura;
    }
}
