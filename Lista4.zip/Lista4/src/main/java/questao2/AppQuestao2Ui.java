package questao2;

import javax.swing.JOptionPane;

public class AppQuestao2Ui {

    public static void main(String[] args) {
        
        Retangulo retangulo = new Retangulo();
     
        retangulo.setAltura(Integer.parseInt(JOptionPane.showInputDialog("Informe a altura")));
        retangulo.setComprimento(Integer.parseInt(JOptionPane.showInputDialog("Informe o comprimento")));

        JOptionPane.showMessageDialog(null, "Perimetro: " + retangulo.calcularPerimetro());
        JOptionPane.showMessageDialog(null, "Area: " + retangulo.calularArea());
    }   
}
