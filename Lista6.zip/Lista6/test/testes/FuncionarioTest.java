/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package testes;

import model.FaixaIRPF;
import model.Funcionario;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author kauan
 */
public class FuncionarioTest {
    
    public FuncionarioTest() {
    }
    @Test
    public void Primeiro(){
        Funcionario f1 = new Funcionario("Ana", 850);
        assertEquals(0.00, f1.calcularIrpf(), 0.00);
        assertEquals(FaixaIRPF.PRIMEIRA,f1.identificarFaixaIrpf());   
    }
    @Test
    public void CalcularImposto(){
        Funcionario f1 = new Funcionario("Ana", 850);
        assertEquals(0.00, f1.calcularIrpf(), 0.00);
    }
    @Test
    public void PrimeiraFaixa(){
        Funcionario f1 = new Funcionario("José", 1903.98);
        assertEquals(FaixaIRPF.PRIMEIRA,f1.identificarFaixaIrpf());
    }
    @Test
    public void CalcularImposto1(){
        Funcionario f1 = new Funcionario("José", 1903.98);
        assertEquals(0.00, f1.calcularIrpf(), 0.00);
    }
    @Test
    public void Segunda(){
        Funcionario f1 = new Funcionario("Jubileu", 1903.99);
        assertEquals(FaixaIRPF.SEGUNDA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto(){
        Funcionario f1 = new Funcionario("Aretusa", 1903.99);
        assertEquals(0.00, f1.calcularIrpf(), 7.50);
    }
    @Test
    public void Segunda1(){
        Funcionario f1 = new Funcionario("aa", 2000.00);
        assertEquals(FaixaIRPF.SEGUNDA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto1(){
        Funcionario f1 = new Funcionario("Aretusa", 2000.00);
        assertEquals(0.01, f1.calcularIrpf(), 7.20);
    }
    @Test
    public void Segunda2(){
        Funcionario f1 = new Funcionario("a", 2826.65);
        assertEquals(FaixaIRPF.SEGUNDA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto2(){
        Funcionario f1 = new Funcionario("Aretusa", 2826.65);
        assertEquals(0.01, f1.calcularIrpf(), 69.20);
    }
    @Test
    public void Terceira(){
        Funcionario f1 = new Funcionario("a", 2826.66);
        assertEquals(FaixaIRPF.TERCEIRA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto3(){
        Funcionario f1 = new Funcionario("a", 2826.66);
        assertEquals(0.01, f1.calcularIrpf(), 69.20);
    }
    @Test
    public void Terceira1(){
        Funcionario f1 = new Funcionario("a", 3000.00);
        assertEquals(FaixaIRPF.TERCEIRA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto4(){
        Funcionario f1 = new Funcionario("a", 3000.00);
        assertEquals(0.01, f1.calcularIrpf(), 95.20);
    }
    @Test
    public void Terceira2(){
        Funcionario f1 = new Funcionario("a", 3751.05);
        assertEquals(FaixaIRPF.TERCEIRA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto5(){
        Funcionario f1 = new Funcionario("a", 3751.05);
        assertEquals(0.01, f1.calcularIrpf(), 207.86);
    }
    @Test
    public void Quarta(){
        Funcionario f1 = new Funcionario("a", 3751.06);
        assertEquals(FaixaIRPF.QUARTA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto6(){
        Funcionario f1 = new Funcionario("a", 3751.06);
        assertEquals(0.01, f1.calcularIrpf(), 207.86);
    }
    @Test
    public void Quarta1(){
        Funcionario f1 = new Funcionario("a", 4000.00);
        assertEquals(FaixaIRPF.QUARTA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto7(){
        Funcionario f1 = new Funcionario("a", 4000.00);
        assertEquals(0.01, f1.calcularIrpf(), 263.87);
    }
    @Test
    public void Quarta2(){
        Funcionario f1 = new Funcionario("a", 4664.68);
        assertEquals(FaixaIRPF.QUARTA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto8(){
        Funcionario f1 = new Funcionario("a", 4664.68);
        assertEquals(0.01, f1.calcularIrpf(), 413.42);
    }
    @Test
    public void Quinta(){
        Funcionario f1 = new Funcionario("a", 4664.69);
        assertEquals(FaixaIRPF.QUINTA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto9(){
        Funcionario f1 = new Funcionario("a", 4664.69);
        assertEquals(0.01, f1.calcularIrpf(), 413.42);
    }
    @Test
    public void Quinta1(){
        Funcionario f1 = new Funcionario("a", 5000.00);
        assertEquals(FaixaIRPF.QUINTA,f1.identificarFaixaIrpf());
    }
    @Test
    public void Imposto10(){
        Funcionario f1 = new Funcionario("a", 5000.00);
        assertEquals(0.01, f1.calcularIrpf(), 505.64);
    }
    @Test(expected = IllegalArgumentException.class)
    public void RecusarValor() {
        Funcionario f1 = new Funcionario("Ana", - 100);
        f1.setSalario(-100);
    }
}
