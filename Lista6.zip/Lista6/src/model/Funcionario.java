package model;

public class Funcionario {

    public Funcionario(String nome, double salario) {
        this.nome = nome;
        this.salario = salario;
    }

    private String nome;
    private double salario;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        if (salario < 0) {
            throw new IllegalArgumentException("Valor negado");
        }
        this.salario = salario;
    }

    public double calcularIrpf() {
        double diferenca = 0;
        double imposto = 0;

        if (getSalario() > 1903.98) {

            if (getSalario() >= 1903.99 && getSalario() <= 2826.65) {
                diferenca = getSalario() - 1903.98;
                imposto = diferenca * 0.075;
            } else if (getSalario() >= 2826.66 && getSalario() <= 3751.05) {
                diferenca = 2826.65 - 1903.98;
                imposto = diferenca * 0.075;
                diferenca = getSalario() - 2826.65;
                imposto += (diferenca * 0.15);
            } else if (getSalario() <= 4664.69) {
                diferenca = 2826.65 - 1903.98;
                imposto = diferenca * 0.075;
                diferenca = 3751.05 - 2826.65;
                imposto += diferenca * 0.15;
                diferenca = getSalario() - 3751.05;
                imposto += diferenca * 0.225;
            } else {
                diferenca = 2826.65 - 1903.98;
                imposto = diferenca * 0.075;
                diferenca = 3751.05 - 2826.65;
                imposto += diferenca * 0.15;
                diferenca = 4664.68 - 3751.05;
                imposto += diferenca * 0.225;
                diferenca = getSalario() - 4664.68;
                imposto += diferenca * 0.275;
            }
        }
        return imposto;
    }

    public FaixaIRPF identificarFaixaIrpf() {
        if (getSalario() <= 1903.98) {
            return FaixaIRPF.PRIMEIRA;
        } else if (getSalario() <= 2826.65) {
            return FaixaIRPF.SEGUNDA;
        } else if (getSalario() <= 3751.05) {
            return FaixaIRPF.TERCEIRA;
        } else if (getSalario() <= 4664.68) {
            return FaixaIRPF.QUARTA;
        } else {
            return FaixaIRPF.QUINTA;
        }
    }
}
