package model;

public class Ponto {
    
    private int x;
    private int y;
    
    /*
    * x recebe x
    * y recebe y
    */
    public Ponto(int x, int y){
        this.x = x;
        this.y = y;
    }
    
    /*
    * definir parametros 
    */
    public Ponto(){
        x = 0;
        y = 0;
    }
    
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }
    
    /*
    * identificar quadrante
    */
    public Quadrante identificarQuadrante(){
        if (x > 0 && y > 0){
            return Quadrante.PRIMEIRO;
        } else if (x < 0 && y > 0){
            return Quadrante.SEGUNDO;
        } else if (x < 0 && y < 0){
            return Quadrante.TERCEIRO;
        } else if (x > 0 && y < 0){
            return Quadrante.QUARTO;
        } else {
            return Quadrante.NENHUM;
        }
    }
    
    /*
    * 
    */
    public boolean estaIncidindoSobreX(){
        return x == 0;
    }
    
    public boolean estaIncidindoSobreY(){
        return y == 0;
    }
    
    /*
    * calcular parametro
    */
    public double calcularDistancia(Ponto outroPonto){
        
        double a = (outroPonto.getX() - this.getX());
        double b = (outroPonto.getY() - this.getY());
        double d = Math.sqrt(Math.pow(a,2) + Math.pow(b,2));
        
        return d;
    }
    
    /*
    * calcular de um ponto para outro
    */
    public double calcularDistancia(Ponto p1, Ponto p2){
        
        double d = p1.calcularDistancia(p2);
       
       return d;
    }
}
