package model;

public enum Quadrante {
    
    NENHUM, PRIMEIRO, SEGUNDO, TERCEIRO, QUARTO;
    
}
