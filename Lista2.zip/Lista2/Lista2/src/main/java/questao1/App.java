/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package questao1;
import java.util.Scanner;
/**
 *
 * @author Hyakume
 */
public class App {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        Pessoa[] pessoa = new Pessoa[3];
        
        for (int i = 0; i < pessoa.length; i++) {
            
            Pessoa p = new Pessoa();
            
            System.out.println("Qual o nome da "+(i+1)+" pessoa: ");
            p.setNome(teclado.next());            
            System.out.println("Qual o seu peso? ");
            p.setPeso(teclado.nextDouble());
            System.out.println("Qual a sua altura? ");
            p.setAltura(teclado.nextDouble());
            
            pessoa[i] = p;
        }  
        
        for (int i = 2; i >= 0; i--) {
            
            System.out.println("Nome: "+pessoa[i].getNome());
            System.out.println("Peso: "+pessoa[i].getPeso());
            System.out.println("Altura: "+pessoa[i].getAltura());
            System.out.println("IMC: "+pessoa[i].calcularImc());
        }        
    }    
}
