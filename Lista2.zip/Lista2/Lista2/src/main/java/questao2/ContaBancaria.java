
package questao2;

public class ContaBancaria {
   
    private String numero;
    private String titular;
    private double saldo;
    
    public ContaBancaria(String titular){
        this.setTitular(titular);
    }
   
    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public void depositar(double valor){
        if (valor <= 0){
            System.out.println("Valor recusado, deposite valores positivos");
        } else if (valor > 0){
            System.out.println("O valor foi depositado");
            saldo += valor;
        }       
    }
    
    public void sacar(double valor){
        
        if(valor <= 0){
            System.out.println("Saque negado, use valor positivo");
        } else if (valor > saldo){
            System.out.println("Saque negado, seu saldo ira fica negativo");
        } else {
            saldo -= valor;
        }        
    }
    
    public void tranferir(double valor, ContaBancaria contaDestino){
        
        if(valor <= 0){
            System.out.println("Saque negado, use valor positivo");
        } else if (valor > saldo){
            System.out.println("Saque negado, seu saldo ira fica negativo");
        } else {
           this.sacar(valor);
           contaDestino.depositar(valor);
            System.out.println("Transferencia realizada");
        }        
    }    
}
