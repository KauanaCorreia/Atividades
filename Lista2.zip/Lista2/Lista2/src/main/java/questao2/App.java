
package questao2;

import java.util.Scanner;

public class App {

    public static void main(String[] args) {
        
        Scanner teclado = new Scanner(System.in);
        
        System.out.println("Nome do titular da primeira conta:");
        String titular1 = teclado.next();
        ContaBancaria conta1 = new ContaBancaria(titular1);
        
        System.out.println("Nome do titular da segunda conta:");
        String titular2 = teclado.next();
        ContaBancaria conta2 = new ContaBancaria(titular2);
        
        conta1.depositar(1000); 
        conta1.depositar(700);
        
        conta2.depositar(5000);
        
        conta2.sacar(3000);
        
        conta2.tranferir(1800, conta1);
        
        System.out.println("Saldo do titular " +conta1.getTitular() + " é de: " +conta1.getSaldo());
        System.out.println("Saldo do titular " +conta2.getTitular() + " é de: " +conta2.getSaldo());
    }    
}
