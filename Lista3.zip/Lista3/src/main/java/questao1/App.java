package questao1;

import java.util.Scanner;

public class App {
     
    public static void main(String[] args) throws IllegalAccessException {
        
        Scanner teclado = new Scanner(System.in);
        Funcionario[] pessoa = new Funcionario[5];
        
        for (int i = 0; i < pessoa.length; i++) {
            
            Funcionario p = new Funcionario();
                
            System.out.println("Qual o nome da "+(i+1)+"° pessoa:");
            p.setNome(teclado.next());
            System.out.println("Qual o salario da "+(i+1)+"° pessoa:");
            p.setSalario(teclado.nextDouble());
            
            pessoa[i] = p;   
        }    
        
        for (int i = 0; i < 5; i++) {
            
            System.out.println("Nome: "+pessoa[i].getNome());
            System.out.println("Salario: " +pessoa[i].getSalario());
            System.out.println("IRPF: " +pessoa[i].calcularIrpf());
        }
        
    }
}