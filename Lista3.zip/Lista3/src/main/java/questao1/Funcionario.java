package questao1;

public class Funcionario {
    
    private String nome;
    private double salario;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) throws IllegalAccessException {
        if(salario < 0){
            throw new IllegalAccessException("Valor negado");
        }
        this.salario = salario;
    }
    
    public double calcularIrpf(){
        double diferenca = 0;
        double imposto = 0; 
        
        if (this.salario <= 1903.98){
            imposto = 0;
        } else if (this.salario > 1903.98 && this.salario <= 2826.65){ //2°
            diferenca = this.salario - 1903.98;
            imposto = diferenca * (7.5 / 100);
        } else if(this.salario > 2826.65 && this.salario <= 3751.05){ //3°
            diferenca = this.salario - 2826.65;
            imposto = diferenca * (15.0 / 100);
        } else if(this.salario > 3751.05 && this.salario <= 4664.68){ //4°
            diferenca = this.salario - 3751.05;
            imposto = diferenca * (22.5 / 100);
        } else if(this.salario > 4664.68){
            diferenca = this.salario - 4664.68; 
            imposto = diferenca * (27.5 / 100);
        }
        return imposto;
    } 
}
